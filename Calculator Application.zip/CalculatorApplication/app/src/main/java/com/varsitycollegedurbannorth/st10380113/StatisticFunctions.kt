package com.varsitycollegedurbannorth.st10380113

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class StatisticFunctions : AppCompatActivity() {

    private var Numbers = ArrayList<Int>()

    lateinit var displayText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistic_functions)

        Log.i("[Testing]","OnCreate Works");

        displayText = findViewById<TextView>(R.id.tvStored)
        var edtNumber = findViewById<EditText>(R.id.edtNumber)
        var btnAdd = findViewById<Button>(R.id.btnAdd)
        var btnClear = findViewById<Button>(R.id.btnClear)
        var btnMinMax = findViewById<Button>(R.id.btnMinMax)
        var btnAverage = findViewById<Button>(R.id.btnAverage)
        var tvAnswer = findViewById<TextView>(R.id.tvAnswer)
        var btnBack = findViewById<Button>(R.id.btnBack)

        btnAdd.setOnClickListener {
            if (Numbers.size < 10) {
                val value = edtNumber.text.toString()

                if (value.isNotEmpty()) {
                    val value = value.toIntOrNull()

                    if (value != null) {
                        Numbers.add(value)
                        edtNumber.text.clear()
                        displayArrayContents()
                    } else {
                        Toast.makeText(
                            this,
                            "Empty field! Please enter a number.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }else {
                Toast.makeText(this, "Array is full! Please clear the array.", Toast.LENGTH_SHORT).show()
            }
        }

            btnClear.setOnClickListener {
                //all the numbers previously populated in the array is now removed
                Numbers.clear()
                displayText.setText("")
            }

            btnMinMax.setOnClickListener {
                if (Numbers.isNotEmpty()) {
                    val min = Numbers.minOrNull()
                    val max = Numbers.maxOrNull()

                    tvAnswer.text = "Minimum: $min\n Maximum: $max"
                } else {
                    tvAnswer.text = "No Numbers Found."
                }
            }

            btnAverage.setOnClickListener {
                //if the array is not empty, then the code inside the if-else statement will be executed
                if (Numbers.isNotEmpty()) {
                    //stores the total of all the numbers in the array added together
                    var sum = 0.0
                    //a loop that goes to every number in the array and adds it to the sum variable
                    for (value in Numbers) {
                        sum += value
                    }
                    //the total of all the numbers in the array is divided by the number of elements in the array
                    //conversion to double for a more accurate floating-point
                    val average = sum / Numbers.size
                    tvAnswer.text = "The average is $average"
                } else {
                    tvAnswer.text = "No Numbers Found."
                }
            }

        btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }

    private fun displayArrayContents() {
        val arrayContent = Numbers.joinToString(separator = ";")
        displayText.text = arrayContent
    }
}