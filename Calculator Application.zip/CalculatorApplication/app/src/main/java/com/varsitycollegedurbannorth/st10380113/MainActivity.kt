package com.varsitycollegedurbannorth.st10380113

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Create variables and get reference to the ID using the View method
        var btnAdd = findViewById<Button>(R.id.btnAdd)

        var tvDisplay = findViewById<TextView>(R.id.tvDisplay)

        var tvError = findViewById<TextView>(R.id.tvError)

        var edtNum1 = findViewById<EditText>(R.id.edtNum1)

        var edtNum2 = findViewById<EditText>(R.id.edtNum2)

        var btnSubtract = findViewById<Button>(R.id.btnSubtract)

        var btnMultiply = findViewById<Button>(R.id.btnMultiply)

        var btnDivide = findViewById<Button>(R.id.btnDivide)

        var btnSquareRoot = findViewById<Button>(R.id.btnSquareRoot)

        var btnPower = findViewById<Button>(R.id.btnPower)

        var btnStats = findViewById<Button>(R.id.btnStats)

        btnAdd.setOnClickListener {

            Log.i("[Testing]","Add Works");
            //create and initialize variables
            val Num1 = edtNum1.text.toString().toInt()
            val Num2 = edtNum2.text.toString().toInt()

            //create and initialize a variable
            //add the two numbers entered to each other
            val Answer = Num1 + Num2

            //create and initialize a variable
            //create a string that contains the entire equation with the numbers entered and the answer
            val Result = "$Num1 + $Num2 = $Answer"

            //display the equation
            tvDisplay.text = Result
        }


        btnSubtract.setOnClickListener {

            //create and initialize variables
            val Num1 = edtNum1.text.toString().toInt()
            val Num2 = edtNum2.text.toString().toInt()

            //create and initialize a variable
            //subtract the two numbers entered from each other
            val Answer = Num1 - Num2

            //create and initialize a variable
            //create a string that contains the entire equation with the numbers entered and the answer
            val Result = "$Num1 - $Num2 = $Answer"

            //display the equation
            tvDisplay.text = Result
        }

        btnMultiply.setOnClickListener {

            //create and initialize variables
            val Num1 = edtNum1.text.toString().toInt()
            val Num2 = edtNum2.text.toString().toInt()

            //create and initialize a variable
            //multiply the two numbers entered with each other
            val Answer = Num1 * Num2

            //create and initialize a variable
            //create a string that contains the entire equation with the numbers entered and the answer
            val Result = "$Num1 x $Num2 = $Answer"

            //display the equation
            tvDisplay.text = Result
        }

        btnDivide.setOnClickListener {
            //create and initialize variables
            val Num1 = edtNum1.text.toString().toDouble()
            val Num2 = edtNum2.text.toString().toDouble()

            if (Num2 == 0.0) {
                tvError.text = "Error: Division by 0 is not allowed"
            }else{
                //create and initialize a variable
                //divide the two numbers entered together
                val Answer = Num1/ Num2
                tvDisplay.text= "$Num1 / $Num2 = $Answer"


            }
        }

        btnSquareRoot.setOnClickListener {
            val Num1 = edtNum1.text.toString().toDouble()
            val Result = Math.sqrt(Num1)

            if (Num1 < 0) {
                val Result = Math.sqrt(Math.abs(Num1))
                tvDisplay.text = "sqrt($Num1) = ${Result} i"
            } else {
                val Result = Math.sqrt(Num1)
                tvDisplay.text = "sqrt($Num1) = $Result"
            }
        }

        btnPower.setOnClickListener {
            //create and initialize variables
            val Num1=edtNum1.text.toString().toDouble()
            val Num2=edtNum2.text.toString().toDouble()
            val Sum = Math.pow(Num1, Num2)

            tvDisplay.text= "" + Num1 + "^" + Num2 + "=" + Sum
        }

        btnStats.setOnClickListener {
            Log.i("[Testing]","Listener Works");
            val intent = Intent(this, StatisticFunctions::class.java)
            startActivity(intent)
        }
    }
}
